
    export const FIREBASE_CONFIG  = {
      apiKey: "AIzaSyCDjtxby59p459bAp_0RLiP_QV8UOfivAo",
      authDomain: "fir-auth-dc312.firebaseapp.com",
      databaseURL: "https://fir-auth-dc312.firebaseio.com",
      projectId: "fir-auth-dc312",
      storageBucket: "fir-auth-dc312.appspot.com",
      messagingSenderId: "145240669196"
    };
    