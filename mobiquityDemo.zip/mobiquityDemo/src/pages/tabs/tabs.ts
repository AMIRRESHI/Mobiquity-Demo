import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { RedditsPage } from '../reddits/reddits';
import { AboutPage } from '../about/about';
import { SettingsPage } from '../settings/settings';
import { LoginPage } from '../login/login';
import { AngularFireAuth } from 'angularfire2/auth';

// @IonicPage({
   
// })

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  tab1Root: any = RedditsPage;
  tab2Root: any = SettingsPage;
  tab3Root: any = AboutPage;

  constructor(private afAuth: AngularFireAuth, public navCtrl: NavController,private alertCtrl: AlertController) {

  }
  // ionViewCanEnter(): boolean | Promise<any> {
  //   const isAllowed = false; // some expression here

  //   console.log('TestPage: ionViewCanEnter:', isAllowed);
  //   if (!isAllowed) {
  //     // can't navigate in the same tick
  //     setTimeout(() => {
  //       console.log('TestPage: redirect');
  //       this.navCtrl.setRoot(AboutPage);
  //     }, 0);
  //   }
  //   return isAllowed;
  // }

  // ionViewCanEnter(): Promise<any>{
  //   return new Promise((resolve, reject) => {
  //     this.auth.getUser().then((user: firebase.User) => {            
  //       resolve(true);        
  //     }).catch(() => {
  //       resolve(false);
  //     });
  //   })
  // }
  logOut() {

    try {
      const logout = this.afAuth.auth.signOut();
      
      if(logout){
        this.showConfirm();
        console.log('logged out');
        
      }else
        console.log('error logged out');

    } catch (e) {
      console.error(e);
    }
  }
  showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Logout Confirmation',
      message: 'Are you sure to Logout',
      buttons: [
        {
          text: 'No',
          handler: () => {
          }
        },
        {
          text: 'Yes',
          handler: () => {
            this.navCtrl.setRoot(LoginPage);

          }
        }
      ]
    });
    confirm.present();
  }


  
}