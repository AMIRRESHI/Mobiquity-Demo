import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, AlertController } from 'ionic-angular';
import { User } from '../../models/user';
import { AngularFireAuth } from 'angularfire2/auth';
import { TabsPage } from '../tabs/tabs';
import { AboutPage } from '../about/about';
import { RegisterPage } from '../register/register';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  user= {} as User;
  loginError: string;

  constructor(private afAuth: AngularFireAuth, public navCtrl: NavController, public navParams: NavParams, private toast: ToastController,public alertCtrl: AlertController) {
  }
  
  async login(user: User){
  
      if (!user.email || !user.password){
        this.showErrorAlert('Please Enter valid Credentials');
        return;
      }
        
      this.afAuth.auth.signInWithEmailAndPassword(user.email, user.password)
			.then(
        () => this.loggedIn(),
        // //error => this.loginError = error.message
        error => this.showErrorAlert(error.message)
      );
  }

  loggedIn(){
    this.navCtrl.setRoot(TabsPage);
    this.showLoginToast();
  }

  showLoginToast() {
    this.afAuth.authState.subscribe(data => {
      
      if (data && data.email && data.uid) {
        this.toast.create({
          message: `Welcome , ${data.email}`,
          duration: 2000
        }).present();
      }
    })
  }
  showErrorAlert(messageData){
    let alert = this.alertCtrl.create({
      title: 'Attention!',
      subTitle: messageData,
      buttons: ['OK']
    });
    alert.present();
  }
  register(){
    this.navCtrl.push('RegisterPage');
    //this.navCtrl.setRoot(TabsPage);
  }

}
