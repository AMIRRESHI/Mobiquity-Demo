import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { User } from '../../models/user';
import { AngularFireAuth } from 'angularfire2/auth';
import { LoginPage } from '../login/login';

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  user = {} as User;

  constructor(private afAuth: AngularFireAuth, public navCtrl: NavController, public navParams: NavParams, public alertCtrl: AlertController) {
  }


  async register(user: User) {

    try {
      const result = await this.afAuth.auth.createUserAndRetrieveDataWithEmailAndPassword(user.email, user.password);

      if (result) {
        //console.log('New Account Created & login will be active after few seconds');
        this.showRegisterAlert();
      }
    } catch (e) {
      this.showErrorAlert(e);
    }
  }

  showRegisterAlert() {
    let alert = this.alertCtrl.create({
      title: 'Registered Sucessfully!',
      subTitle: 'New Account Created & login will be active after few seconds!',
      buttons: [
        {
          text: 'Ok',
          handler: () => {
            this.navCtrl.push(LoginPage);

          }
        }
      ]
    });
    alert.present();
  }

  showErrorAlert(messageData) {
    let alert = this.alertCtrl.create({
      title: 'Attention!',
      subTitle: messageData,
      buttons: ['OK']
    });
    alert.present();
  }
}


